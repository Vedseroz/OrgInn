package proyecto;

public class Main {

	public static void main (String args[]){

		Hotel _H = new Hotel();
	
	}
}
